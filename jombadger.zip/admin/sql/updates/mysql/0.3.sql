ALTER TABLE `#__jb_badges` ADD `catid` int(11) NOT NULL DEFAULT '0'
