ALTER TABLE `#__jb_records` ADD `transfered` BOOLEAN NULL DEFAULT NULL COMMENT '1 if transfered to backpack'
