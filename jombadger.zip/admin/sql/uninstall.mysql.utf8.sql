DROP TABLE `#__jb_badges`;
